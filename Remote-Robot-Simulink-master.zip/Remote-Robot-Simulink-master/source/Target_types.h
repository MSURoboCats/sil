/*
 * File: Target_types.h
 *
 * Code generated for Simulink model 'Target'.
 *
 * Model version                  : 1.28
 * Simulink Coder version         : 8.4 (R2013a) 13-Feb-2013
 * TLC version                    : 8.4 (Jan 19 2013)
 * C/C++ source code generated on : Fri Apr 11 21:37:06 2014
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Target_types_h_
#define RTW_HEADER_Target_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct P_Target_T_ P_Target_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Target_T RT_MODEL_Target_T;

#endif                                 /* RTW_HEADER_Target_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
